package db.conexion.Repositorys;

import java.util.List;

import db.conexion.models.Empleado;
import interfaces.Repositoryinterface;

public class EmpleadoRepository implements Repositoryinterface<Empleado> {

    @Override
    public void agregar(Empleado entidad) {
        // TODO Auto-generated method stub

    }

    @Override
    public void eliminar(Empleado entidad) {
        // TODO Auto-generated method stub

    }

    @Override
    public void modificar(Empleado entidad) {
        // TODO Auto-generated method stub

    }

    @Override
    public List<Empleado> recuperarTodos() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Empleado recuperarid(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

}
