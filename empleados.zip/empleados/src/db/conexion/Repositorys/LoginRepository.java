package db.conexion.Repositorys;

public class LoginRepository {
    public boolean iniciarSesion;

}
